package com.example.torres_j_cs360_proj2_2eventtracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.torres_j_cs360_proj2_2eventtracker.DTO.EventCreateRequest;
import com.example.torres_j_cs360_proj2_2eventtracker.DTO.EventDto;
import com.example.torres_j_cs360_proj2_2eventtracker.DTO.EventsListResponse;
import com.example.torres_j_cs360_proj2_2eventtracker.repository.EventsRepo;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeActivity extends AppCompatActivity {
    private EventAdapter adapter;
    private ArrayList<Event> events = new ArrayList<>();
    private EventsRepo eventsRepo;
    private EditText editEventName;
    private Button btnAddEvent;

    private String userId;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // from SharedPref
        var prefs = getSharedPreferences("auth", MODE_PRIVATE);
        userId = prefs.getString("userId", null);
        username = prefs.getString("username", null);

        if (userId == null || username == null) {
            Toast.makeText(this, "Please log in again", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        // views
        RecyclerView recyclerView = findViewById(R.id.recyclerView);

        editEventName = findViewById(R.id.editEventName);
        btnAddEvent = findViewById(R.id.btnAddEvent);

        adapter = new EventAdapter(events, new EventAdapter.OnDeleteClickListener() {

            @Override
            public void OnDeleteClick(int position) {
                if (position < 0 || position >= events.size()) return;
                Event ev = events.get(position);

                eventsRepo.deleteEvent(ev.getId(), new Callback<>() {
                    @Override
                    public void onResponse(Call<Void> call, Response<Void> res) {
                        if (res.isSuccessful()) {
                            // Remove from list and notify adapter
                            events.remove(position);
                            adapter.notifyItemRemoved(position);

                            toast("Deleted");
                        } else {
                            toast("Delete failed (" + res.code() + ")");
                        }
                    }
                    @Override
                    public void onFailure(Call<Void> call, Throwable t) {
                        toast("Network error: " + safeMsg(t));
                    }
                });
            }

            @Override
            public void OnUpdateClick(int position, String newTitle) {
                Event event = events.get(position);

                var patch = new java.util.HashMap<String, Object>();
                patch.put("title", newTitle);

                eventsRepo.updateEvent(event.getId(), patch, new Callback<>() {
                    @Override
                    public void onResponse(Call<EventDto> call, Response<EventDto> resp) {
                        if (!resp.isSuccessful() || resp.body() == null) {
                            toast("Update failed (" + resp.code() + ")");
                            return;
                        }
                        // update UI model
                        event.setTitle(resp.body().getTitle());
                        adapter.notifyItemChanged(position);
                    }

                    @Override
                    public void onFailure(Call<EventDto> call, Throwable t) {
                        toast("Network error: " + safeMsg(t));
                    }
                });
            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        eventsRepo = new EventsRepo();

        // Load first page
        loadEventsPage(1, 20);

        // Add new
        btnAddEvent.setOnClickListener(v -> {
            String title = safe(editEventName);
            if (title.isEmpty()) {
                toast("Please enter an event title");
                return;
            }

            EventCreateRequest req = new EventCreateRequest(
                    userId,
                    title,
                    "", // notes
                    isoUtcNow(),
                    isoUtcPlusHours(1),
                    "medium",
                    "open",
                    new java.util.ArrayList<>() // tags
            );

            btnAddEvent.setEnabled(false);
            eventsRepo.createEvent(req, new Callback<>() {
                @Override
                public void onResponse(Call<EventDto> call, Response<EventDto> resp) {
                    btnAddEvent.setEnabled(true);
                    if (!resp.isSuccessful() || resp.body() == null) {
                        toast("Create failed (" + resp.code() + ")");
                        return;
                    }
                    EventDto d = resp.body();
                    events.add(mapToUi(d));
                    adapter.notifyItemInserted(events.size() - 1);
                    editEventName.setText("");
                }

                @Override
                public void onFailure(Call<EventDto> call, Throwable t) {
                    btnAddEvent.setEnabled(true);
                    toast("Network error: " + safeMsg(t));
                }
            });
        });
    }

    private void loadEventsPage(int page, int size) {
        eventsRepo.listEvents(
                null, null,      // from,to
                null,            // title contains
                "startAt", "asc",
                page, size,
                new Callback<>() {
                    @Override
                    public void onResponse(Call<EventsListResponse> call, Response<EventsListResponse> resp) {
                        if (!resp.isSuccessful() || resp.body() == null) {
                            toast("Load failed (" + resp.code() + ")");
                            return;
                        }
                        List<EventDto> items = resp.body().getItems();
                        events.clear();
                        for (EventDto d : items) events.add(mapToUi(d));
                        adapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onFailure(Call<EventsListResponse> call, Throwable t) {
                        toast("Network error: " + safeMsg(t));
                    }
                }
        );
    }

    // mapping dto
    private Event mapToUi(EventDto d) {
        Event e = new Event();
        e.setId(d.get_id());
        e.setTitle(d.getTitle());
        return e;
    }

    private static String safeMsg(Throwable t) {
        return t == null || t.getMessage() == null ? "unknown" : t.getMessage();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private static String safe(EditText et) {
        return et.getText() == null ? "" : et.getText().toString().trim();
    }

    private static String isoUtcNow() {
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US);
        f.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
        return f.format(new java.util.Date());
    }

    private static String isoUtcPlusHours(int h) {
        long ms = System.currentTimeMillis() + (h * 3600_000L);
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US);
        f.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
        return f.format(new java.util.Date(ms));
    }
}
