package com.example.torres_j_cs360_proj2_2eventtracker.network;


import com.example.torres_j_cs360_proj2_2eventtracker.Config;
import com.example.torres_j_cs360_proj2_2eventtracker.repository.TokenStore;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public final class RetrofitClient {
    private static Retrofit retrofit;

    public static Retrofit getInstance() {
        if (retrofit == null) {
            // Logging
            HttpLoggingInterceptor logger = new HttpLoggingInterceptor();
            logger.setLevel(HttpLoggingInterceptor.Level.BODY);

            // for token auth for okHttpClient
            Interceptor authInterceptor = chain -> {
                Request original = chain.request();
                String token = null;
                try { token = TokenStore.get().getToken(); } catch (IllegalStateException ignored) {}
                android.util.Log.d("AuthInt", "Token present? " + (token != null && !token.isEmpty()));
                if (token == null || token.isEmpty()) {
                    return chain.proceed(original);
                }
                Request authed = original.newBuilder()
                        .header("Authorization", "Bearer " + token)
                        .build();
                return chain.proceed(authed);
            };

            OkHttpClient client = new OkHttpClient.Builder()
                    .addInterceptor(authInterceptor)
                    .addInterceptor(logger)
                    .build();

            Gson gson = new GsonBuilder()
                    .setDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
                    .create();

            retrofit = new Retrofit.Builder()
                    .baseUrl(Config.BASE_URL)
                    .client(client)
                    .addConverterFactory(GsonConverterFactory.create(gson))
                    .build();
        }
        return retrofit;
    }
}