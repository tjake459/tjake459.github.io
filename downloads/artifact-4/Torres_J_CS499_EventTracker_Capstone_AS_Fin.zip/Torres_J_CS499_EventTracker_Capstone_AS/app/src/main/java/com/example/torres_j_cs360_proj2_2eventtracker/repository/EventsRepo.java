package com.example.torres_j_cs360_proj2_2eventtracker.repository;

import com.example.torres_j_cs360_proj2_2eventtracker.DTO.EventCreateRequest;
import com.example.torres_j_cs360_proj2_2eventtracker.DTO.EventDto;
import com.example.torres_j_cs360_proj2_2eventtracker.DTO.EventsListResponse;
import com.example.torres_j_cs360_proj2_2eventtracker.network.ApiClient;
import com.example.torres_j_cs360_proj2_2eventtracker.network.EventsApi;

import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;

public class EventsRepo {
    private final EventsApi api;

    public EventsRepo() {
        this.api = ApiClient.create(EventsApi.class);
    }

    // READ LIST
    public void listEvents(
            String fromIso,
            String toIso,
            String title,
            String sort,
            String dir,
            Integer page,
            Integer size,
            Callback<EventsListResponse> cb
    ) {
        // defaults
        String s = (sort == null) ? "startAt" : sort;
        String d = (dir == null) ? "asc"     : dir;
        Integer p = (page == null) ? 1       : page;
        Integer z = (size == null) ? 20      : size;

        api.listEvents(fromIso, toIso, title, s, d, p, z).enqueue(cb);
    }

    // CREATE
    public void createEvent(EventCreateRequest body, Callback<EventDto> cb) {
        api.createEvent(body).enqueue(cb);
    }

    // UPDATE
    public void updateEvent(String id, Map<String, Object> patch, Callback<EventDto> cb) {
        api.updateEvent(id, patch).enqueue(cb);
    }

    // DELETE
    public void deleteEvent(String id, Callback<Void> cb) {
        api.deleteEvent(id).enqueue(cb);
    }
}
