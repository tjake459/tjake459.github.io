package com.example.torres_j_cs360_proj2_2eventtracker.network;

import com.example.torres_j_cs360_proj2_2eventtracker.DTO.AuthResponses;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Headers;
import retrofit2.http.POST;
public interface AuthApi {

    @FormUrlEncoded
    @Headers("Accept: application/json")
    @POST("api/auth/login")
    Call<AuthResponses.LoginResponse> login(
            @Field("username") String username,
            @Field("password") String password
    );

    @FormUrlEncoded
    @Headers("Accept: application/json")
    @POST("api/auth/signup")
    Call<AuthResponses.SignupResponse> signup(
            @Field("username") String username,
            @Field("password") String password
    );
}
