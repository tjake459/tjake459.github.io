package com.example.torres_j_cs360_proj2_2eventtracker;

public class User {

    private int id;

    private String username;

    private String password;

    private boolean smsPermission;

    public User(int id, String username, String password, boolean smsPermission) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.smsPermission = smsPermission;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isSmsPermission() {
        return smsPermission;
    }

    public void setSmsPermission(boolean smsPermission) {
        this.smsPermission = smsPermission;
    }
}
