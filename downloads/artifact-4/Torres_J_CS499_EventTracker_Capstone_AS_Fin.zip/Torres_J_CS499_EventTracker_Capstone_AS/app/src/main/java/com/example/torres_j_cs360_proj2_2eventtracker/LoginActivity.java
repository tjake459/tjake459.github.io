package com.example.torres_j_cs360_proj2_2eventtracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.torres_j_cs360_proj2_2eventtracker.DTO.AuthResponses;
import com.example.torres_j_cs360_proj2_2eventtracker.repository.AuthRepo;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    private EditText editUsername, editPassword;
    private Button btnLogin, btnSignup;

    private AuthRepo authRepo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // wires up views
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnSignup = findViewById(R.id.btnSignup);

        authRepo = new AuthRepo();

        btnLogin.setOnClickListener(v -> doLogin());
        btnSignup.setOnClickListener(v -> doSignup());
    }

        private void doLogin() {
            String username = safeText(editUsername);
            String password = safeText(editPassword);

            if (username.isEmpty() || password.isEmpty()) {
                toast("Please enter all fields");
                return;
            }

            // Disable buttons to avoid double taps during the call
            setButtonsEnabled(false);

            authRepo.login(username, password, new Callback<>() {
                @Override
                public void onResponse(Call<AuthResponses.LoginResponse> call,
                                       Response<AuthResponses.LoginResponse> resp) {
                    setButtonsEnabled(true);

                    if (!resp.isSuccessful() || resp.body() == null) {
                        toast("Login failed (" + resp.code() + ")");
                        return;
                    }

                    AuthResponses.LoginResponse body = resp.body();
                    String userId = body.getUserId();
                    String uname = body.getUsername();

                    if (userId == null || uname == null) {
                        toast("Unexpected login response");
                        return;
                    }

                    // save
                    getSharedPreferences("auth", MODE_PRIVATE)
                            .edit()
                            .putString("userId", userId)
                            .putString("username", uname)
                            .apply();

                    toast("Login successful!");
                    Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                    intent.putExtra("userId", userId);
                    intent.putExtra("username", uname);
                    startActivity(intent);
                    finish();
                }

                @Override
                public void onFailure(Call<AuthResponses.LoginResponse> call, Throwable t) {
                    setButtonsEnabled(true);
                    toast("Network error: " + (t.getMessage() == null ? "unknown" : t.getMessage()));
                }
            });
        }

    private void doSignup() {
        String username = safeText(editUsername);
        String password = safeText(editPassword);

        if (username.isEmpty() || password.isEmpty()) {
            toast("Please enter all fields");
            return;
        }

            authRepo.signup(username, password, new Callback<>() {
                @Override
                public void onResponse(Call<AuthResponses.SignupResponse> call,
                                       Response<AuthResponses.SignupResponse> resp) {
                    setButtonsEnabled(true);

                    if (!resp.isSuccessful() || resp.body() == null) {
                        toast("Signup failed (" + resp.code() + ")");
                        return;
                    }

                    toast("Sign up successful!");
                    Intent intent = new Intent(LoginActivity.this, SmsPermissionActivity.class);
                    intent.putExtra("username", username);
                    startActivity(intent);
                    finish();
                }

                @Override
                public void onFailure(Call<AuthResponses.SignupResponse> call, Throwable t) {
                    setButtonsEnabled(true);
                    toast("Network error: " + (t.getMessage() == null ? "unknown" : t.getMessage()));
                }
            });
        }

    private String safeText(EditText et) {
        return et.getText() == null ? "" : et.getText().toString().trim();
    }

    private void toast(String msg) {
        Toast.makeText(LoginActivity.this, msg, Toast.LENGTH_SHORT).show();
    }

    private void setButtonsEnabled(boolean enabled) {
        btnLogin.setEnabled(enabled);
        btnSignup.setEnabled(enabled);
    }
}