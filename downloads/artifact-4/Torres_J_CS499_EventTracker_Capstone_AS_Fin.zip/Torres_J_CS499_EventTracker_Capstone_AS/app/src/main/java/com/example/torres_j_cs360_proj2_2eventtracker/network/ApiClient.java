package com.example.torres_j_cs360_proj2_2eventtracker.network;
import static java.util.concurrent.TimeUnit.SECONDS;

import android.content.Context;
import android.util.Log;

import com.example.torres_j_cs360_proj2_2eventtracker.Config;
import com.example.torres_j_cs360_proj2_2eventtracker.repository.TokenStore;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public final class ApiClient {
    private ApiClient() {}

    public static <T> T create(Class<T> api) {
        return RetrofitClient.getInstance().create(api);
    }
}

