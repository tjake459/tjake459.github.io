package com.example.torres_j_cs360_proj2_2eventtracker.DTO;

public class AuthResponses {
    public static class LoginResponse {
        private String userId;
        private String username;
        private String token;
        public String getUserId(){ return userId; }
        public String getUsername(){ return username; }
        public String getToken(){ return token; }
    }

    public static class SignupResponse {
        private String userId;
        private String username;
        private String token;
        public String getUserId(){ return userId; }
        public String getUsername(){ return username; }
        public String getToken(){ return token; }
    }
}

