package com.example.torres_j_cs360_proj2_2eventtracker;

public class Event {
    private String id;
    private String title;

    public Event() {

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }


}

