package com.example.torres_j_cs360_proj2_2eventtracker.DTO;

import java.util.List;

public class EventCreateRequest {
    private  String userId;
    private  String title;
    private  String notes;
    private  String startAt;
    private  String endAt;
    private  String priority;
    private  String status;
    private  List<String> tags;

    public EventCreateRequest(String userId, String title, String notes, String startAt, String endAt, String priority, String status, List<String> tags) {
        this.userId = userId;
        this.title = title;
        this.notes = notes;
        this.startAt = startAt;
        this.endAt = endAt;
        this.priority = priority;
        this.status = status;
        this.tags = tags;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getStartAt() {
        return startAt;
    }

    public void setStartAt(String startAt) {
        this.startAt = startAt;
    }

    public String getEndAt() {
        return endAt;
    }

    public void setEndAt(String endAt) {
        this.endAt = endAt;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }
}
