package com.example.torres_j_cs360_proj2_2eventtracker.network;

import com.example.torres_j_cs360_proj2_2eventtracker.DTO.EventCreateRequest;
import com.example.torres_j_cs360_proj2_2eventtracker.DTO.EventDto;
import com.example.torres_j_cs360_proj2_2eventtracker.DTO.EventsListResponse;

import java.util.Map;
import retrofit2.Call;
import retrofit2.http.*;

public interface EventsApi {

    // GET /events?userId=
    @GET("api/events")
    @Headers("Accept: application/json")
    Call<EventsListResponse> listEvents(
            @Query("from") String fromIso,
            @Query("to") String toIso,
            @Query("title") String title,
            @Query("sort") String sort,
            @Query("dir") String dir,
            @Query("page") Integer page,
            @Query("size") Integer size
    );

    // POST /events
    @POST("api/events")
    Call<EventDto> createEvent(@Body EventCreateRequest body);

    // PUT /events/:id
    @PUT("api/events/{id}")
    Call<EventDto> updateEvent(@Path("id") String id, @Body Map<String, Object> patch);

    @DELETE("api/events/{id}")
    Call<Void> deleteEvent(@Path("id") String id);

}

