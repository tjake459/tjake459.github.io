package com.example.torres_j_cs360_proj2_2eventtracker;

public class Config {
    public static final String BASE_URL = "http://10.0.2.2:3000/";
    private Config() {};
}
