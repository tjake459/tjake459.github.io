package com.example.torres_j_cs360_proj2_2eventtracker.DTO;

import java.util.List;

public class EventsListResponse {
    public List<EventDto> items;
    public int page;
    public int size;
    public int total;
    public boolean hasMore;

    public List<EventDto> getItems() {
        return items;
    }

    public void setItems(List<EventDto> items) {
        this.items = items;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public boolean isHasMore() {
        return hasMore;
    }

    public void setHasMore(boolean hasMore) {
        this.hasMore = hasMore;
    }
}
