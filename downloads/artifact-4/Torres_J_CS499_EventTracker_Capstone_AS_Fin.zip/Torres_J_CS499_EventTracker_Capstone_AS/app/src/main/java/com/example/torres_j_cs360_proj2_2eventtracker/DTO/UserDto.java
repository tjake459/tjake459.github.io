package com.example.torres_j_cs360_proj2_2eventtracker.DTO;

import com.google.gson.annotations.SerializedName;

public class UserDto {
    @SerializedName("_id")
    private String id;

    private String username;
    private boolean smsPermission;
    private String createdAt; // ISO-8601 from backend

    public void setId(String id) {
        this.id = id;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setSmsPermission(boolean smsPermission) {
        this.smsPermission = smsPermission;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getId() { return id; }
    public String getUsername() { return username; }
    public boolean isSmsPermission() { return smsPermission; }
    public String getCreatedAt() { return createdAt; }
}
