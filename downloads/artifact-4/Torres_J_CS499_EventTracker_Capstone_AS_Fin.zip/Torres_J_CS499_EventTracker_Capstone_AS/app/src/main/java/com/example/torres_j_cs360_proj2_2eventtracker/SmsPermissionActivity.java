package com.example.torres_j_cs360_proj2_2eventtracker;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.content.Intent;

import com.example.torres_j_cs360_proj2_2eventtracker.repository.UsersRepo;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class SmsPermissionActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 123;
    private String username;
    private String userId;
    private UsersRepo usersRepo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        // saved at login/signup
        username = getIntent().getStringExtra("username");
        var prefs = getSharedPreferences("auth", MODE_PRIVATE);
        if (username == null) {
            username = prefs.getString("username", null);
        }
        userId = prefs.getString("userId", null);

        // If missing auth, send back to login
        if (userId == null || username == null) {
            Toast.makeText(this, "Please log in again", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        usersRepo = new UsersRepo();

        Button btnPermission = findViewById(R.id.btnPermission);
        Button btnDeny = findViewById(R.id.btnDeny);

        btnPermission.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_CODE
                );
            } else {
                onDecision(true);
            }
        });

        btnDeny.setOnClickListener(v -> onDecision(false));
    }

    private void onDecision(boolean allowed) {
        var prefs = getSharedPreferences("auth", MODE_PRIVATE).edit();
        prefs.putBoolean("smsPermission", allowed).apply();

        usersRepo.updateSmsPermission(userId, allowed, new Callback<>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> resp) {
                if (!resp.isSuccessful()) {
                    Toast.makeText(SmsPermissionActivity.this,
                            "Saved locally. Server update failed (" + resp.code() + ")",
                            Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(SmsPermissionActivity.this,
                            allowed ? "Permission saved. Thank you!" : "Opted out of SMS alerts.",
                            Toast.LENGTH_SHORT).show();
                }
                goHome();
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Toast.makeText(SmsPermissionActivity.this,
                        "Saved locally. Network error: " + (t.getMessage() == null ? "unknown" : t.getMessage()),
                        Toast.LENGTH_SHORT).show();
                goHome();
            }
        });

    }

    private void goHome() {
        startActivity(new Intent(SmsPermissionActivity.this, HomeActivity.class));
        finish();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            onDecision(granted);
        }
    }
}

