package com.example.torres_j_cs360_proj2_2eventtracker.repository;

import com.example.torres_j_cs360_proj2_2eventtracker.network.ApiClient;
import com.example.torres_j_cs360_proj2_2eventtracker.network.UsersApi;

import java.util.HashMap;
import java.util.Map;

import retrofit2.Callback;

public class UsersRepo {
    private final UsersApi api;

    public UsersRepo() {
        this.api = ApiClient.create(UsersApi.class);
    }

    public void updateSmsPermission(String userId, boolean allowed, Callback<Void> cb) {
        Map<String, Object> patch = new HashMap<>();
        patch.put("smsPermission", allowed);
        api.updateUser(userId, patch).enqueue(cb);
    }
}
