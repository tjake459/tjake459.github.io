package com.example.torres_j_cs360_proj2_2eventtracker.repository;

import com.example.torres_j_cs360_proj2_2eventtracker.DTO.AuthResponses;
import com.example.torres_j_cs360_proj2_2eventtracker.network.ApiClient;
import com.example.torres_j_cs360_proj2_2eventtracker.network.AuthApi;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AuthRepo {
    private final AuthApi api;

    public AuthRepo() {
        this.api = ApiClient.create(AuthApi.class);
    }

    public void login(String username, String password, Callback<AuthResponses.LoginResponse> cb) {
        api.login(username, password).enqueue(new Callback<>() {
            @Override
            public void onResponse(Call<AuthResponses.LoginResponse> call,
                                   Response<AuthResponses.LoginResponse> resp) {
                if (resp.isSuccessful() && resp.body() != null) {
                    // Save JWT from server
                    try {
                        TokenStore.get().save(resp.body().getToken());
                    } catch (IllegalStateException ignored) {}
                }
                // Forward to caller
                cb.onResponse(call, resp);
            }

            @Override
            public void onFailure(Call<AuthResponses.LoginResponse> call, Throwable t) {
                cb.onFailure(call, t);
            }
        });
    }

    public void signup(String username, String password, Callback<AuthResponses.SignupResponse> cb) {
        api.signup(username, password).enqueue(new Callback<>() {
            @Override
            public void onResponse(Call<AuthResponses.SignupResponse> call,
                                   Response<AuthResponses.SignupResponse> resp) {
                if (resp.isSuccessful() && resp.body() != null) {
                    // Save JWT from server
                    try {
                        TokenStore.get().save(resp.body().getToken());
                    } catch (IllegalStateException ignored) {}
                }
                // Forward to caller
                cb.onResponse(call, resp);
            }

            @Override
            public void onFailure(Call<AuthResponses.SignupResponse> call, Throwable t) {
                cb.onFailure(call, t);
            }
        });
    }
}
