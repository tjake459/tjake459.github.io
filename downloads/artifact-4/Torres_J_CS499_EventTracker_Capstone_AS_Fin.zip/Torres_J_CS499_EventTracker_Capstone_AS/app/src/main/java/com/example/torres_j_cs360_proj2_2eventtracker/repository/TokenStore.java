package com.example.torres_j_cs360_proj2_2eventtracker.repository;
import android.content.Context;
import android.content.SharedPreferences;

public final class TokenStore {
    private static TokenStore INSTANCE;
    private final SharedPreferences prefs;
    private static final String PREFS = "auth_prefs";
    private static final String KEY = "jwt_token";

    public TokenStore(Context ctx) {
        prefs = ctx.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static synchronized void init(Context ctx) {
        if (INSTANCE == null) INSTANCE = new TokenStore(ctx);
    }

    public static TokenStore get() {
        if (INSTANCE == null) throw new IllegalStateException("TokenStore not initialized");
        return INSTANCE;
    }

    public void save(String token) { prefs.edit().putString(KEY, token).apply(); }
    public String getToken() { return prefs.getString(KEY, null); }
    public void clear() { prefs.edit().remove(KEY).apply(); }
}

