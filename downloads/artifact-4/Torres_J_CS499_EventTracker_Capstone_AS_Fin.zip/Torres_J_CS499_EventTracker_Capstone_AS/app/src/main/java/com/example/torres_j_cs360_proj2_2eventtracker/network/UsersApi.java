package com.example.torres_j_cs360_proj2_2eventtracker.network;

import java.util.Map;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface UsersApi {
    // PUT /api/users/{id} -> smsPermission: true/false
    @PUT("api/users/{id}")
    Call<Void> updateUser(@Path("id") String userId, @Body Map<String, Object> patch);
}
