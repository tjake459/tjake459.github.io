package com.example.torres_j_cs360_proj2_2eventtracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.ViewHolder> {
    private ArrayList<Event> eventList;
    private OnDeleteClickListener deleteClickListener;

    public interface OnDeleteClickListener {
        void OnDeleteClick(int position);
        void OnUpdateClick(int position, String newTitle);
    }

    public EventAdapter(ArrayList<Event> events, OnDeleteClickListener listener) {
        this.eventList = events;
        this.deleteClickListener = listener;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView eventText;
        Button btnDelete;
        Button btnUpdate;

        public ViewHolder(View itemView) {
            super(itemView);
            eventText = itemView.findViewById(R.id.eventText);
            btnDelete = itemView.findViewById(R.id.btnDelete);
            btnUpdate = itemView.findViewById(R.id.btnUpdate);
        }
    }

    @Override
    public EventAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.event_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(EventAdapter.ViewHolder holder, int position) {
        Event event = eventList.get(position);
        holder.eventText.setText(event.getTitle());

        holder.btnDelete.setOnClickListener(v -> {
            if (deleteClickListener != null) {
                deleteClickListener.OnDeleteClick(position);
            }
        });

        holder.btnUpdate.setOnClickListener(v -> {
            String updatedTitle = holder.eventText.getText().toString();
            if (deleteClickListener != null) {
                deleteClickListener.OnUpdateClick(position, updatedTitle);
            }
        });
    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }
}

