package com.example.torres_j_cs360_proj2_2eventtracker;

import android.app.Application;
import com.example.torres_j_cs360_proj2_2eventtracker.repository.TokenStore;

public class MyApp extends Application {
    @Override public void onCreate() {
        super.onCreate();
        TokenStore.init(getApplicationContext());
    }
}
