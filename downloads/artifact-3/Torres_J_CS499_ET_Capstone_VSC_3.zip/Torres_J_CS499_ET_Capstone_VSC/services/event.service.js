const mongoose = require('mongoose');
const Event = require('../models/event');

const buildQuery = ({ userId, from, to, title }) => {
  if (!userId || !mongoose.isValidObjectId(userId)) {
    throw new Error('Invalid or missing userId');
  }
  const q = { userId: new mongoose.Types.ObjectId(userId) };

  if (from || to) {
    const start = from ? new Date(from) : new Date('1970-01-01T00:00:00.000Z');
    const end   = to   ? new Date(to)   : new Date('9999-12-31T23:59:59.999Z');
    if (isNaN(start) || isNaN(end) || start > end) throw new Error('Invalid date range');
    q.startAt = { $lte: end };
    q.endAt   = { $gte: start };
  }

  if (title && title.trim()) q.titleLower = title.trim().toLowerCase();
  return q;
};

const buildSort = ({ sort = 'startAt', dir = 'asc' }) => {
  const allowed = new Set(['startAt', 'title', 'priority', 'createdAt']);
  const field = allowed.has(sort) ? sort : 'startAt';
  const order = dir === 'desc' ? -1 : 1;
  return { [field]: order };
};

const list = async (params) => {
  const q = buildQuery(params);
  const sort = buildSort(params);
  const page = Math.max(parseInt(params.page, 10) || 1, 1);
  const size = Math.min(Math.max(parseInt(params.size, 10) || 20, 1), 100);

  const [items, total] = await Promise.all([
    Event.find(q)
      .select('title startAt endAt priority status tags createdAt')
      .sort(sort).skip((page - 1) * size).limit(size).lean(),
    Event.countDocuments(q),
  ]);

  return { items, total, page, size, hasMore: page * size < total, sort, q };
};

module.exports = { list };
