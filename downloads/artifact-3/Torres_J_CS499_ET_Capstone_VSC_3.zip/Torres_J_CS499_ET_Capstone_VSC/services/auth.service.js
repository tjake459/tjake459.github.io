// services/auth.service.js
const mongoose = require('mongoose');
const User = require('../models/user');

function safeUser(u) {
  return { id: u._id.toString(), username: u.username, smsPermission: !!u.smsPermission };
}

async function signup({ username, password }) {
  if (!username || !password) {
    const err = new Error('Username and password required');
    err.status = 400; throw err;
  }
  const existing = await User.findOne({ username }).exec();
  if (existing) {
    const err = new Error('User already exists');
    err.status = 409; throw err;
  }
  // TODO: replace with bcrypt hash later
  const user = await User.create({ username, passwordHash: password, smsPermission: false });
  return safeUser(user);
}

async function login({ username, password }) {
  const user = await User.findOne({ username }).exec();
  if (!user || user.passwordHash !== password) {
    const err = new Error('Invalid username or password');
    err.status = 401; throw err;
  }
  return safeUser(user);
}

async function updateUser(id, updates = {}) {
  if (!mongoose.isValidObjectId(id)) {
    const err = new Error('Invalid user id');
    err.status = 400; throw err;
  }
  const user = await User.findByIdAndUpdate(id, updates, { new: true }).exec();
  if (!user) {
    const err = new Error('User not found');
    err.status = 404; throw err;
  }
  return safeUser(user);
}

module.exports = { signup, login, updateUser };
