const express = require('express');
const router = express.Router();
const auth = require('../../controllers/auth.controller');

// POST /api/auth/signup = create user
router.post('/signup', auth.signup);

// POST /api/auth/login   = authenticate user
router.post('/login', auth.login);

// PUT /api/auth/:id      = update user 
router.put('/:id', auth.updateUser);

module.exports = router;