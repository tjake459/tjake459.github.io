const express = require('express');
const router = express.Router();
const events = require('../../controllers/events.controller');

router.get('/', events.eventsList);
router.get('/:id', events.eventsFindById);
router.post('/', events.eventsAddEvent);
router.put('/:id', events.eventsUpdateEvent);

module.exports = router;