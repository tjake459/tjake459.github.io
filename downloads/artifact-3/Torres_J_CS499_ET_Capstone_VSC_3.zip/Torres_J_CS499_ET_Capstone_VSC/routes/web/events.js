const express = require('express');
const router = express.Router();
const eventService = require('../../services/event.service');

// GET /events  -> render the home page with events for a user
router.get('/', async (req, res) => {
  try {
    const { userId, username, from, to, title, sort, dir, page, size } = req.query;

    const data = await eventService.list({ userId, from, to, title, sort, dir, page, size });

    const sortField = Object.keys(data.sort)[0];
    const sortDir = data.sort[sortField] === -1 ? 'desc' : 'asc';

    res.render('events/home', {
      title: 'Your Events',
      username: username || '',
      userId,
      events: data.items,
      page: data.page,
      size: data.size,
      total: data.total,
      sort: sortField,
      dir: sortDir,
      from,
      to,
      titleFilter: title
    });
  } catch (err) {
    console.error('GET /events error:', err);
    res.status(500).render('error', { message: 'Server error' });
  }
});

module.exports = router;