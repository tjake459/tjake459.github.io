const express = require('express');
const router = express.Router();
const authService = require('../../services/auth.service');

// GET /login
// GET /signup
router.get('/login',  (req, res) => res.render('auth/login',  { title: 'Log In' }));
router.get('/signup', (req, res) => res.render('auth/signup', { title: 'Create Account' }));

// POST /login
router.post('/login', async (req, res) => {
  try {
    const user = await authService.login(req.body);
    return res.redirect(`/events?userId=${user.id}&username=${encodeURIComponent(user.username)}`);
  } catch (e) {
    return res.status(e.status || 500)
      .render('auth/login', { title: 'Log In', error: e.message || 'Server error' });
  }
});

// POST /signup
router.post('/signup', async (req, res) => {
  try {
    const user = await authService.signup(req.body);
    return res.redirect(`/events?userId=${user.id}&username=${encodeURIComponent(user.username)}`);
  } catch (e) {
    return res.status(e.status || 500)
      .render('auth/signup', { title: 'Create Account', error: e.message || 'Server error' });
  }
});

module.exports = router;