const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    username: {type: String, required: true, unique: true, trim: true },
    passwordHash: { type: String, required: true },
    smsPermission: { type: Boolean, default: false },
},
{ timestamps: true }
);

// hide pw
userSchema.methods.toSafeJSON = function () {
  const obj = this.toObject();
  delete obj.password;
  return obj;
};

module.exports = mongoose.model('User', userSchema);