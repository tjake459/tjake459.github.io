const mongoose = require("mongoose")

const eventSchema = new mongoose.Schema(
    {
        userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
        title: { type: String, required: true, trim: true },
        titleLower: { type: String, index: true },  // for case-insensitive search
        notes: { type: String, default: '' },
        startAt: { type: Date },
        endAt: { type: Date },
        priority: { type: String, enum: ['low', 'medium', 'high'], default: 'medium' },
        status: { type: String, enum: ['open', 'in-progress', 'completed'], default: 'open' },
        tags: { type: [String], default: [] },
    },
    { timestamps: true } // automatically adds createdAt + updatedAt
);

// keep normalized title
eventSchema.pre('save', function(next) {
  if (this.isModified('title')) {
    this.titleLower = this.title.toLowerCase();
  }
  next();
});

// indexes that make queries fast
eventSchema.index({ userId: 1, startAt: 1 });
eventSchema.index({ userId: 1, titleLower: 1 });

module.exports = mongoose.model('Event', eventSchema);