const mongoose = require('mongoose');
const User = require('../models/user');
const authService = require('../services/auth.service');

// POST api/signup
const signup = async (req, res) => {
  try {
    const user = await authService.signup(req.body);
    return res.status(201).json({ userId: user.id, username: user.username });
  } catch (e) {
    console.error('API signup error:', e);
    return res.status(e.status || 500).json({ message: e.message || 'Server error' });
  }
};

// POST api/login
const login = async (req, res) => {
  try {
    const user = await authService.login(req.body);
    return res.status(200).json({ userId: user.id, username: user.username });
  } catch (e) {
    console.error('API login error:', e);
    return res.status(e.status || 500).json({ message: e.message || 'Server error' });
  }
};

// POST api/updateUser
const updateUser = async (req, res) => {
  try {
    const user = await authService.updateUser(req.params.id, req.body);
    return res.status(200).json({ user });
  } catch (e) {
    console.error('API update user error:', e);
    return res.status(e.status || 500).json({ message: e.message || 'Server error' });
  }
};

module.exports = {
  signup,
  login,
  updateUser
};
