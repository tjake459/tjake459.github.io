const mongoose = require('mongoose');
const Event = require('../models/event');
const eventService = require('../services/event.service');

// GET: /events - lists all the events, handles sorting and date filtering and user tracking
// Regardless of outcome, response includes HTML status code
// and JSON message to the requesting client
const eventsList = async(req, res) => {
  try {
    const data = await eventService.list(req.query);
    return res.status(200).json(data);
  } catch (err) {
    console.error('eventsList error:', err);
    return res.status(500).json({ message: 'Server error' });
  }
};

// GET: /events/:id - Lists a single trip
// response include HTML status code
// and JSON message to the requesting client
const eventsFindById = async(req, res) => {
  try {
    const { id } = req.params;
    if (!mongoose.isValidObjectId(id)) return res.status(400).json({ message: 'Invalid id' });

    const q = await Model.findById(id).exec();
    console.log(q);

    if (!q) {
      return res.status(404).json({ message: 'Event not found' });
    }
    return res.status(200).json(q);
  } catch (err) {
    console.error('eventsFindById error:' , err);
    return res.status(500).json({ message: 'Server error' });
  }
};

// POST: /events - Adds a new Event
// response include HTML status code
// and JSON message to the requesting client
const eventsAddEvent = async(req, res) => {
  try {
    const body = req.body;
    if (!body.userId || !mongoose.isValidObjectId(body.userId)) {
      return res.status(400).json({ message: 'userId required' });
    }

    if (!body.title || !body.startAt || !body.endAt) {
      return res.status(400).json({ message: 'title, startAt, endAt required' });
    }

    const s = new Date(body.startAt), e = new Date(body.endAt);
    if (isNaN(s) || isNaN(e) || s > e) {
      return res.status(400).json({ message: 'Invalid start/end' });
    }

    const doc = await Event.create({
      userId: body.userId,
      title: body.title,
      notes: body.notes || '',
      startAt: s,
      endAt: e,
      priority: body.priority || 'medium',
      status: body.status || 'open',
      tags: Array.isArray(body.tags) ? body.tags : []
    });

    return res.status(201).json(doc);
  } catch (err) {
    console.error('eventsAddEvent error:', err);
    return res.status(500).json({ message: 'Server error' });
  }
};

// PUT: /events/:id - updates an Event
// response include HTML status code
// and JSON message to the requesting client
const eventsUpdateEvent = async(req, res) => {
  try {
    const { id } = req.params;
    if (!mongoose.isValidObjectId(id)) return res.status(400).json({ message: 'Invalid id' });

    const patch = { ...req.body };
    if (patch.startAt) patch.startAt = new Date(patch.startAt);
    if (patch.endAt)   patch.endAt   = new Date(patch.endAt);
    if (patch.startAt && isNaN(patch.startAt)) return res.status(400).json({ message: 'Invalid startAt' });
    if (patch.endAt && isNaN(patch.endAt))     return res.status(400).json({ message: 'Invalid endAt' });
    if (patch.startAt && patch.endAt && patch.startAt > patch.endAt)
      return res.status(400).json({ message: 'startAt must be <= endAt' });

    const q = await Model.findByIdAndUpdate(
      id,
      { $set: patch  },
      { new: true }
    ).exec();

    if (!q) {
      return res.status(404).json({ message: 'Event not found' });
    }
    return res.status(200).json(q);
  } catch (err) {
    console.error('eventsUpdateEvent error:', err);
    return res.status(500).json({ message: 'Server error' });
  }
};

module.exports = {
    eventsList,
    eventsFindById,
    eventsAddEvent,
    eventsUpdateEvent
};