const express = require('express');
const router = express.Router();

// GET /login  -> render login page
router.get('/login', (req, res) => {
  res.render('auth/login', { title: 'Log In' });
});

// GET /signup -> render signup page
router.get('/signup', (req, res) => {
  res.render('auth/signup', { title: 'Create Account' });
});

module.exports = router;