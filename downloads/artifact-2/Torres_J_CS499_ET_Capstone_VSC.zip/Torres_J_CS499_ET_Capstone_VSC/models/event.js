module.exports = class Event {
    constructor({ id, userId, title, notes = '', startAt = null, endAt = null, priority = 'medium', status = 'open', tags = [], createdAt = new Date(), updatedAt = new Date() }) {
        this.id = id;
        this.userId = userId;
        this.title = title;
        this.notes = notes;
        this.startAt = startAt;
        this.endAt = endAt;
        this.priority = priority;
        this.status = status;
        this.tags = tags;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }
}