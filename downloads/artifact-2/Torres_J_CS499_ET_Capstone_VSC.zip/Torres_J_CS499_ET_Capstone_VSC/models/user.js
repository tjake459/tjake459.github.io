module.exports = class User {
    constructor({ id, username, passwordHash, smsPermission = false, createdAt = new Date() }) {
        this.id = id;
        this.username = username;
        this.passwordHash = passwordHash;   // will correctly store password later
        this.smsPermission = smsPermission;
        this.createdAt = createdAt;
    }
}