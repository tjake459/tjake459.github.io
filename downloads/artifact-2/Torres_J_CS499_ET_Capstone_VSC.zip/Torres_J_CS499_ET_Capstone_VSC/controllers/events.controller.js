let EVENTS = []; // will replace with mongo later

exports.list = (req, res) => {
  const username = req.query.username || 'guest';
  const events = EVENTS.filter(e => e.username === username);
  res.render('events/home', { title: 'My Events', username, events });
};

exports.create = (req, res) => {
  const { title, username } = req.body;
  EVENTS.push({ id: EVENTS.length + 1, username, title, createdAt: new Date() });
  res.redirect(`/api/events?username=${encodeURIComponent(username)}`);
};