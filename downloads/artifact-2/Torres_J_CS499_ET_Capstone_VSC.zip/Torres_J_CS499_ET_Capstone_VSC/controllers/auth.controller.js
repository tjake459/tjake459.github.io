let USERS = [];    // will replace with Mongo later

// Login

exports.getLogin = (req, res) => {
    res.render('auth/login', {title: 'Login'});
};

exports.postLogin = (req, res) => {
    const { username } = req.body;
    const user = USERS.find(u => u.username === username);
    if (!user) {
        // Failed login
        return res.status(400).render('auth/login', { title: 'Login', error: 'User not found. Please signup.'});
    }
    // Succesful login, goes to events
    return res.redirect(`/api/events?username=${encodeURIComponent(username)}`);
};

// Sign up

exports.getSignup = (req, res) => {
    res.render('auth/signup', { title: 'Sign Up' });
};

exports.postSignup = (req, res) => {
    const { username } = req.body;
    if (!username || !username.trim()) {
        // Failed Signup
        return res.status(400).render('auth/signup', { title: 'Sign Up', error: 'Username is required.'});
    }
    const exists = USERS.some(u => u.username.toLowerCase() === username.toLowerCase());
    if (exists) {
        // Duplicate username
        return res.status(400).render('auth/signup', { title: 'Sign Up', error: 'Username already exists.'})
    }

    const newUser = {id: USERS.length + 1, username: username.trim(), smsPermission: false};
    USERS.push(newUser);

    // Succesful signup, goes to events
    return res.redirect(`/api/events?username=${encodeURIComponent(newUser.username)}`);
}