const express = require('express');
const router = express.Router();
const events = require('../../controllers/events.controller');

router.get('/', events.list);
router.post('/', events.create);

module.exports = router;