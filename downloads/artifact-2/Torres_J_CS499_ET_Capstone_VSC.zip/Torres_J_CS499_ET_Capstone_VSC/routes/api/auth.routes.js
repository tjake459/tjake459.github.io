const express = require('express');
const router = express.Router();
const auth = require('../../controllers/auth.controller');

// Login
router.get('/login', auth.getLogin);
router.post('/login', auth.postLogin);

// Sign up
router.get('/signup', auth.getSignup);
router.post('/signup', auth.postSignup);

module.exports = router;